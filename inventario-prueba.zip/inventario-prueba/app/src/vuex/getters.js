export const mainCounter = state => state.counters.main
