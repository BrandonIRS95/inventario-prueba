import Master from './components/Master.vue'
import MakeSale from './components/MakeSale/Master'
import Products from './components/Products/Master'
import ProductDetail from './components/Products/ProductDetail'
import ProductList from './components/Products/ProductList'
import ProductEntries from './components/Products/ProductEntries.vue'
import ProductOutputs from './components/Products/ProductOutputs.vue'


export default [
  {
    path: '/',
    name: 'home',
    component: Master,
    redirect: 'makesale',
    children: [
      {
        path: '/makesale',
        component: MakeSale,
        name: 'makesale'
      },
      {
        path: '/goods',
        component: Products,
        name: 'products',
          redirect: '/goods/productList',
        children: [
          {
            path: '/goods/productList',
            component: ProductList,
            name: 'productList'
          },
          {
            path: '/goods/productDetail',
            component: ProductDetail,
            name: 'productDetail'
          },
          {
            path: '/goods/productEntries',
            component: ProductEntries,
            name: 'productEntries'
          },
          {
            path: '/goods/productOutputs',
            component: ProductOutputs,
            name: 'productOutputs'
          }
        ]
      }
    ]
  },
  {
    path: '*',
    redirect: '/'
  }
]
