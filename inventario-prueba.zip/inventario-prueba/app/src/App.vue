<template>
    <router-view></router-view>
</template>

<script>
    import './js/TweenMax.min'
    export default {}
</script>
