<script>
    var sections = [
        /*{
            name: 'Goods',
            click: function (router, index) {
                router.push('productList')
                sections.splice(index + 1,sections.length)
            }
        },
        {
            name: 'Detail',
            click: function (router, index) {
                router.push('productDetail')
                sections.splice(index + 1,sections.length)
            }
        },
        {
            name: 'Caca',
            click: function (router) {

            }
        },
        {
            name: 'Popo',
            click: function (router) {

            }
        }*/
    ]

    export default{
        computed: {
            getSections(){
                return sections
            },
            add(item){
                sections.push(item)
            },
            clean(){
                sections.splice(0,sections.length)
            },
            cut(index){
                sections.splice(index + 1, sections.length)
            }
        }
    }
</script>