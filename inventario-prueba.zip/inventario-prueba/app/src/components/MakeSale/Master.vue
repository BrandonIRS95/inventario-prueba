<template>
    <div class="ui segment">
        <h3>Make a sale</h3>
    </div>
</template>
<script>
    import BreadcrumbService from '../BreadcrumbService'

    export default{
        name: 'make-sale',
        beforeCreate() {
            BreadcrumbService.computed.clean()
            BreadcrumbService.computed.add({
                name: 'Make a sale',
                click: function (router, index) {
                    router.push('makesale')
                    BreadcrumbService.computed.cut(index)
                }
            })
        }
    }
</script>