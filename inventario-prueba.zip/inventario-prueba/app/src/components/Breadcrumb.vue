<template>
    <div class="ui segment">
        <div class="ui small breadcrumb">
                <div v-on:click="section.click($router, index)" class="active section" style="cursor: pointer;" v-for="(section, index) in sections">
                    {{section.name}}
                    <i v-if="(index + 1) !== sections.length" class="right chevron icon divider"></i>
                </div>

            </div>
        </div>
    </div>

</template>
<script>

    import BreadcrumbService from './BreadcrumbService'

    export default{
        name: 'breadcrumb',
        data(){
            return{
                sections: BreadcrumbService.computed.getSections()
            }
        }
    }
</script>
