<template>
    <div>
        <menu-bar></menu-bar>
        <div class="ui container" style="margin-top: 15px;">
            <breadcrumb></breadcrumb>
            <transition v-on:enter="enter"
                        v-on:leave="leave"
                        v-bind:css="false"
                        mode="out-in">
                <router-view></router-view>
            </transition>
        </div>
    </div>
</template>
<script>
    import MenuBar from './MenuBar.vue'
    import Breadcrumb from './Breadcrumb.vue'



    export default{
        name: 'app',
        data() {
            return {

            }
        },
        components: {
            MenuBar,
            Breadcrumb
        },
        methods:{
            enter(el, done) {
                TweenMax.from(el, 0.2, {x: '20%', opacity: 0, onComplete: done})
            },
            leave(el, done) {
                TweenMax.to(el, 0.2, {x: '-20%', opacity: 0, onComplete: done})
            }
        }
    }
</script>
<style src="../../../semantic/dist/semantic.min.css"></style>