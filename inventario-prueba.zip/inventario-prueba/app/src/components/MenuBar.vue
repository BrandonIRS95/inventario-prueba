<template>
    <div class="ui attached stackable menu">
        <div class="ui container">
            <router-link to="makesale" class="item">
                <i class="shopping basket icon"></i> Make a sale
            </router-link>
            <router-link to="/goods" class="item">
                <i class="cubes icon"></i> Goods
            </router-link>
            <a class="item">
                <i class="sign in icon"></i> Goods entries
            </a>
            <a class="item">
                <i class="sign out icon"></i> Goods outputs
            </a>
            <div class="right item">
                <div class="ui input"><input type="text" placeholder="Search..."></div>
            </div>
        </div>
    </div>
</template>
<script>

    export default{
        name: 'menu-bar'
    }
</script>