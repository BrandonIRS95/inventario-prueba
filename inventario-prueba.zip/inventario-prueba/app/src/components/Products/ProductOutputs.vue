<template>
    <div class="ui segment">
        <h3><i class="sign out icon"></i>Outputs detail</h3>
        <table class="ui celled table">
            <thead>
            <tr><th>Date</th>
                <th>Quantity</th>
            </tr></thead>
            <tbody>
            <tr v-for="output in item.outputs">
                <td>{{output.date}}</td>
                <td>{{output.quantity}}</td>
            </tr>
            <tr>
                <td><b>TOTAL</b></td>
                <td>{{total}}</td>
            </tr>
            </tbody>

        </table>
    </div>
</template>
<script>
    import ProductsService from './ProductsService.vue'

    export default{
        name: 'product-entries',
        data() {
            return{
                item: ProductsService.computed.getSelected()
            }
        },
        computed: {
            total: function(){
                var totalE = 0
                var outputs = this.item.outputs
                for(var x = 0; x < outputs.length; x++)
                    totalE += outputs[x].quantity

                return totalE
            }
        }
    }
</script>