<template>
    <div class="ui segment">
        <div class="ui grid">
            <div class="two column row">
                <div class="four wide column">
                    <div class="ui card">
                        <div class="image">
                            <img src="../../images/image.png">
                        </div>
                        <div class="content">
                            <div class="header">{{item.name}}</div>
                            <div class="meta">
                                <span class="date">Brand: {{item.description}}</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="twelve wide column">
                    <table class="ui celled table">
                        <thead>
                        <tr><th><i class="sign in icon"></i> Entries</th>
                            <th><i class="sign out icon"></i> Outputs</th>
                            <th><i class="law icon"></i> Balance</th>
                        </tr></thead>
                        <tbody>
                            <tr>
                                <td>{{entries}}</td>
                                <td>{{outputs}}</td>
                                <td>{{storage}}</td>
                            </tr>
                        </tbody>

                    </table>
                    <div class="ui grid">
                        <div class="eight wide column">
                            <button class="fluid ui button" @click="goEntries()">
                                <i class="sign in icon"></i>
                                Entries detail
                            </button>
                        </div>
                        <div class="eight wide column">
                            <button class="fluid ui button" @click="goOutputs()">
                                <i class="sign out icon"></i>
                                Outputs detail
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</template>
<script>
    import BreadcrumbService from '../BreadcrumbService'
    import ProductsService from './ProductsService.vue'

    export default{
        name: 'product-detail',
        data() {
            return{
                item: ProductsService.computed.getSelected(),
                entries: 0,
                outputs: 0
            }
        },
        methods: {
            goEntries(){
                this.$router.push('/goods/productEntries')
                BreadcrumbService.computed.add({
                    name: 'Entries',
                    click: function (router, index) {
                        router.push('/goods/productEntries')
                        BreadcrumbService.computed.cut(index)
                    }
                })
            },
            goOutputs(){
                this.$router.push('/goods/productOutputs')
                BreadcrumbService.computed.add({
                    name: 'Outputs',
                    click: function (router, index) {
                        router.push('/goods/productOutputs')
                        BreadcrumbService.computed.cut(index)
                    }
                })
            }
        },
        computed: {
          storage: function () {
              var totalO = 0
              var totalE = 0
              var entries = this.item.entries
              var outputs = this.item.outputs
              for(var x = 0; x < entries.length; x++)
                  totalE += entries[x].quantity
              for(var x = 0; x < outputs.length; x++)
                  totalO += outputs[x].quantity

              this.entries = totalE
              this.outputs = totalO
              return totalE - totalO
          }
        }
    }
</script>