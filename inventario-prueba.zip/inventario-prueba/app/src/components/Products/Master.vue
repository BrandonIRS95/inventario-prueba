<template>
    <div>
        <transition v-on:enter="enter"
                    v-on:leave="leave"
                    v-bind:css="false"
                    mode="out-in">
            <router-view></router-view>
        </transition>
    </div>
</template>
<script>
    import BreadcrumbService from '../BreadcrumbService'

    export default{
        name: 'products',
        methods: {
            enter(el, done) {
                TweenMax.from(el, 0.2, {x: '20%', opacity: 0, onComplete: done})
            },
            leave(el, done) {
                TweenMax.to(el, 0.2, {x: '-20%', opacity: 0, onComplete: done})
            }
        }
    }
</script>
