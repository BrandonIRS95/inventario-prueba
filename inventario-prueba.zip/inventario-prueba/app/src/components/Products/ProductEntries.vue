<template>
    <div class="ui segment">
        <h3><i class="sign in icon"></i>Entries detail</h3>
        <table class="ui celled table">
            <thead>
            <tr><th>Date</th>
                <th>Quantity</th>
            </tr></thead>
            <tbody>
            <tr v-for="entrie in item.entries">
                <td>{{entrie.date}}</td>
                <td>{{entrie.quantity}}</td>
            </tr>
            <tr>
                <td><b>TOTAL</b></td>
                <td>{{total}}</td>
            </tr>
            </tbody>

        </table>
    </div>
</template>
<script>
    import ProductsService from './ProductsService.vue'

    export default{
        name: 'product-entries',
        data() {
            return{
                item: ProductsService.computed.getSelected()
            }
        },
        computed: {
            total: function(){
                var totalE = 0
                var entries = this.item.entries
                for(var x = 0; x < entries.length; x++)
                    totalE += entries[x].quantity

                return totalE
            }
        }
    }
</script>