<script>
    var products = [
        {
            name: 'Water',
            description: 'Ciel',
            entries: [
                {
                    date: '2016-04-06',
                    quantity: 5
                },
                {
                    date: '2016-04-08',
                    quantity: 10
                },
                {
                    date: '2016-06-23',
                    quantity: 11
                }
            ],
            outputs: [
                {
                    date: '2016-04-06',
                    quantity: 2
                },
                {
                    date: '2016-04-06',
                    quantity: 3
                },
                {
                    date: '2016-04-06',
                    quantity: 1
                }
            ]
        },
        {
            name: 'Shaving foam',
            description: 'Gillete',
            entries: [
                {
                    date: '2016-04-06',
                    quantity: 7
                },
                {
                    date: '2016-04-08',
                    quantity: 10
                },
                {
                    date: '2016-06-23',
                    quantity: 12
                }
            ],
            outputs: [
                {
                    date: '2016-04-06',
                    quantity: 3
                },
                {
                    date: '2016-04-06',
                    quantity: 1
                },
                {
                    date: '2016-04-06',
                    quantity: 1
                }
            ]
        },
        {
            name: 'Apple gerber',
            description: 'Gerber',
            entries: [
                {
                    date: '2016-04-06',
                    quantity: 9
                },
                {
                    date: '2016-04-08',
                    quantity: 7
                },
                {
                    date: '2016-06-23',
                    quantity: 11
                }
            ],
            outputs: [
                {
                    date: '2016-04-06',
                    quantity: 2
                },
                {
                    date: '2016-04-06',
                    quantity: 2
                },
                {
                    date: '2016-04-06',
                    quantity: 4
                }
            ]
        }
    ]

    var selected = {}

    export default{
        computed: {
            getProducts(){
                return products
            },
            getSelected(){
                return selected
            },
            setSelected(item){
                selected = item
            }
        }
    }
</script>