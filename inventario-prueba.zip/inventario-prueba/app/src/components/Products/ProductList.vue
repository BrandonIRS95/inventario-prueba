<template>
    <div class="ui segment">
        <div class="ui divided items">
            <div class="item" v-for="product in products">
                <div class="ui tiny image">
                    <img src="../../images/image.png">
                </div>
                <div class="content">
                    <a v-on:click="toDetail(product)" class="header">{{product.name}}</a>
                    <div class="meta">
                        Brand: <span>{{product.description}}</span>
                    </div>
                    <div class="description">
                        <p></p>
                    </div>
                    <div class="extra">
                        Balance: {{storage(product)}}
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    import BreadcrumbService from '../BreadcrumbService'
    import ProductsService from './ProductsService.vue'

    export default{
        name: 'product-list',
        data() {
            return{
                products: ProductsService.computed.getProducts()
            }
        },
        computed: {
        },
        methods:{
            toDetail(item){
                ProductsService.computed.setSelected(item)
                this.$router.push('/goods/productDetail')
                BreadcrumbService.computed.add({
                    name: item.name,
                    click: function (router, index) {
                        router.push('/goods/productDetail')
                        BreadcrumbService.computed.cut(index)
                    }
                })
            },
            storage(item) {
                var totalO = 0
                var totalE = 0
                var entries = item.entries
                var outputs = item.outputs
                for(var x = 0; x < entries.length; x++)
                    totalE += entries[x].quantity
                for(var x = 0; x < outputs.length; x++)
                    totalO += outputs[x].quantity

                return totalE - totalO
            }
        },
        beforeRouteEnter(to, from, next){
            BreadcrumbService.computed.clean()
            BreadcrumbService.computed.add({
                name: 'Goods',
                click: function (router, index) {
                    router.push('/goods/productList')
                    BreadcrumbService.computed.cut(index)
                }
            })
            next()
        }
    }
</script>